﻿(function (main) {

    main.init = function () {
        var searchBox = document.getElementById("map-search");
        searchBox.onkeyup = function (event) {
            var map = maps.list.find((element) => { return element.name.startsWith(event.target.value); });

            var imageHtml = "";
            map.images.forEach((element) => {

                imageHtml += `
<div>
    <div>${element.title}</div>
    <div>${element.description}</div>
    <image class="map-image" src="${element.url}">
</div>
`;
            });

            var insert = document.getElementById("map-insert");
            insert.innerHTML = imageHtml;
        };
    };

    main.init();
})(window.main = window.main || {});